package objetos.futbol.varios;

import java.util.Scanner;

public class LecturaTeclado {
public static Scanner scan=new Scanner(System.in);
	

}

package objetos.futbol.varios;

public class Posicionamiento {

	public Posicionamiento() {
		// TODO Auto-generated constructor stub
	}

}
